<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="mb-0"><?php echo e($subtitle); ?> </h4>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($title); ?> </a></li>
                <li class="breadcrumb-item active"><?php echo e($subtitle); ?> </li>
            </ol>
        </div>
    </div>
</div><?php /**PATH F:\Personal Projects\Vacay Guider\vacay-admin\resources\views/layouts/partials/page-title.blade.php ENDPATH**/ ?>