<footer class="footer card mb-0 rounded-0 justify-content-center align-items-center">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <p class="mb-0">
                    <script>
                        document.write(new Date().getFullYear())
                    </script> &copy; VacayGuider</a>
                </p>
            </div>
        </div>
    </div>
</footer><?php /**PATH F:\Personal Projects\Vacay Guider\vacay-admin\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>