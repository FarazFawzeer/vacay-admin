<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH F:\Personal Projects\Vacay Guider\vacay-admin\resources\views/layouts/partials/vendor-scripts.blade.php ENDPATH**/ ?>